public class Data{
    int dia;
    int mes;
    int ano;
}